<template>
<div id="add-name">
<h1>Users1</h1>
<div v-for="blog in blogs" v-bind:key="blog.id" class="single-name">
    <h2>{{blog.name}} <a href="showpost.vue">Leanne Graham</a></h2>
</div>
</div>
</template>
    
 <script>
    export default {
       data(){
    return{
blogs:{name:"test"}
    }
  },
      methods:
      {
        post: function() {
            this.$http.get("https://jsonplaceholder.typicode.com/posts",{
                name:this.blogs.name
            }).then(function(data){
                console.log(data);
            });
        }
        }
    }
        
    
    </script>
    <style>
    #add-name{

        max-width:800px;
        margin:0 auto;
    }
#single-name{
      padding:20px;
      margin:20px;
}
    </style>