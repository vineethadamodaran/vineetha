<template>
  <div id="app">
   
    <HelloWorld msg="Hello World!"/>
 
<h1>Names</h1>

<div>
<div v-for="post in posts" :key="post.id" class="post">
<h3>{{ post.title }}</h3>
<p>{{ post.body}}</p>
</div>
</div>
</div>

</template>

<script>
export default{
data() {
return{
 posts:[]
}
},
 mounted() {
  this.$http.get('https://jsonplaceholder.typicode.com/posts')
.then(function(res) {
   this.posts=res.body;
})
.catch( function(error) {
console.log('Error:', error);
})
}
}
</script>
