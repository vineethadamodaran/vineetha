<script src="https://cdn.jsdelivr.net/npm/vue-resource@1.5.1"></script>

<script>
/*import '~coreui/scss/coreui';*/

new Vue({
  el: "#app",
  data: {
    users: [],
    posts: [],
    post: '',
    posts_det: ''
  },
  methods: {
    listuser(id) {
      fetch("https://jsonplaceholder.typicode.com/posts?userId=" + id)
        .then(response => response.json())
        .then((data) => {
          this.post = data;

        })
    },
      listpostdet(id) {
  
      fetch("https://jsonplaceholder.typicode.com/posts?id=" + id)
        .then(response => response.json())
        .then((data) => {
          this.posts_det = data;
      
        })
      },
  },
 
  mounted() {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then(response => response.json())
      .then((data) => {
        this.users = data;
      })
  },
  template: `

  
<div class="col-md-12">

 <div v-for="post_det in posts_det"> 
 <h3>Post Detail</h3>
  <p>{{ post_det.body }}</p>
  </div>
  
  <div v-for="postt in post.slice(0, 10)" class="col-md-6">
  <h2><button class="btn btn-block btn-outline-info active" v-on:click="listpostdet(postt.id)" >{{ postt.title }}</button></h2>
  </div>

  <table class="table table-responsive-sm">
  <thead>
  <tr>
    <th>Name</th>
    <th>User Name</th>
    <th>Email</th>
    <th>Phone</th>
  </tr>
</thead>
<tbody>
  <tr v-for="user in users">
    <td><button class="btn btn-secondary btn-lg btn-block" v-on:click="listuser(user.id)">{{ user.name }}</button></td>
    <td>{{ user.username }}</td>
    <td>{{ user.email }}</td>
    <td>{{ user.phone }}</td>
  </tr>
</tbody>
</table>
 
  
  
 
</div>`,
});
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;  
  margin-top: 60px;
}
</style>
